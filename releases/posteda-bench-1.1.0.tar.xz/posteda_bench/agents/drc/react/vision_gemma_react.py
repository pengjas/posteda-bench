"""
DRC (Design Rule Checking) Error Fixing Agent (vision-enabled) using LangGraph
and a multimodal LLM served locally by vLLM (OpenAI-compatible /v1 endpoint).

The vision_query_with_pts tool returns both text and level_*.png images; the
BasicToolNode below splits them into a ToolMessage (text) plus a HumanMessage
(images) so the OpenAI-compatible endpoint can ingest the image_url parts.

This agent iteratively:
1. Analyzes DRC error reports
2. Queries the layout to understand geometric context (text + images)
3. Applies targeted fixes (move_cell, change_shape, add_shape)
4. Verifies fixes by running DRC again
5. Repeats until errors are resolved or iterations exhausted

CLI surface, system prompt, tool timeouts, AgentState, and error-handling
logic are kept identical to google_react.py so eval_drc_sr.sh can swap agents
without modification. The only real difference is the model instantiation
(vLLM via langchain_openai.ChatOpenAI) and the cost tracker (throughput-
normalized $/token via vllm_cost_tracker).
"""

import json
import os
import traceback
from typing import Annotated, TypedDict
from langchain_core.messages import HumanMessage, AIMessage, ToolMessage, SystemMessage
from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, END
from langgraph.graph.message import add_messages
import argparse
import datetime
import time
from langgraph.errors import GraphRecursionError
import multiprocessing
from typing_extensions import NotRequired

# Import tools from the tools package
from agents.drc.tools import (
    query_drc_report,
    vision_query_with_pts,
    move_cell,
    change_shape,
    add_shape,
)
from agents.ppa.react import vllm_cost_tracker as cost_tracker

# Global counter to track tool calls (persists even when exceptions occur)
tool_call_counter = {"count": 0}


# --- State Definition ---
class AgentState(TypedDict):
    """Shared state in LangGraph workflow"""
    messages: Annotated[list, add_messages]
    drc_errors: Annotated[list, add_messages]
    output_gds: str
    query_change_args: dict
    tool_call_count: NotRequired[int]


def call_llm(state: AgentState):
    print("\n--- CALL LLM: call_llm ---", flush=True)
    print(state["messages"][-1], flush=True)

    # === VISION DEBUG: log image presence in messages being sent to the LLM ===
    for msg in state["messages"]:
        if hasattr(msg, "content") and isinstance(msg.content, list):
            img_count = sum(
                1 for item in msg.content
                if isinstance(item, dict) and item.get("type") == "image_url"
            )
            if img_count > 0:
                print(
                    f"[VISION DEBUG] Message ({type(msg).__name__}) contains {img_count} image(s) being sent to LLM",
                    flush=True,
                )

    # Retry forever: the vLLM server occasionally accepts a request and never
    # responds. Each attempt has a 10s SDK-level timeout (set on ChatOpenAI),
    # so a wedged call abandons the socket and tries again instead of hanging.
    attempt = 0
    while True:
        attempt += 1
        print(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] --- attempt #{attempt}: WAITING for LLM response (per-attempt timeout=10s, msgs={len(state['messages'])}) ... ---", flush=True)
        _llm_t0 = time.time()
        try:
            response = llm_with_tools.invoke(state["messages"])

            _llm_dt = time.time() - _llm_t0
            print(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] LLM call successful! (took {_llm_dt:.1f}s, attempt #{attempt})", flush=True)
            cost_tracker.record_langchain_usage(response)
            print("=================================RESPONSE==================================", flush=True)
            print(response, flush=True)
            print("=================================RESPONSE==================================", flush=True)

            return {"messages": [response]}

        except Exception as e:
            _llm_dt = time.time() - _llm_t0
            print(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] attempt #{attempt} failed after {_llm_dt:.1f}s: {type(e).__name__}: {e}", flush=True)
            print(f"--- retrying ---", flush=True)
            time.sleep(1)
            continue


class BasicToolNode:
    """A node that runs the tools requested in the last AIMessage (with timeout-safe process isolation)."""

    def __init__(self, tools: list) -> None:
        self.tools_by_name = {tool.name: tool for tool in tools}

    def _run_tool(self, tool, args, return_dict):
        """Run tool.invoke in an isolated process and return result or error.

        Stores the *raw* Python object (not json.dumps'd) so vision_query_with_pts
        can be unpacked into separate text + image-bearing messages downstream.
        """
        try:
            result = tool.invoke(args)
            return_dict["result"] = result
        except Exception:
            return_dict["error"] = traceback.format_exc()

    def __call__(self, inputs: dict):
        if messages := inputs.get("messages", []):
            message = messages[-1]
        else:
            raise ValueError("No message found in input")

        outputs = []
        query_change_args = None
        agent_state = {}

        for tool_call in message.tool_calls:
            tool_name = tool_call["name"]
            tool_args = tool_call["args"]
            print(f"\n--- TOOL CALL: Invoking tool '{tool_name}' with args: {tool_args} ---", flush=True)

            manager = multiprocessing.Manager()
            return_dict = manager.dict()

            tool = self.tools_by_name.get(tool_name)
            if tool is None:
                print(f"!!!!!!!!!!!!!!!!!!!!  ERROR: UNKNOWN TOOL  !!!!!!!!!!!!!!!!!!!!", flush=True)
                outputs.append(
                    ToolMessage(
                        content=f"Error: Unknown tool '{tool_name}'.",
                        name=tool_name,
                        tool_call_id=tool_call["id"],
                    )
                )
                continue

            # Start isolated process to execute tool.invoke
            p = multiprocessing.Process(
                target=self._run_tool,
                args=(tool, tool_args, return_dict),
            )

            p.start()
            print(f"--- Waiting for '{tool_name}' (max 1200s)... ---", flush=True)
            p.join(timeout=1200)

            if p.is_alive():
                # Timeout - kill the process
                print(f"!!!!!!!!!!!!!!!!!!!!  ERROR: TIMEOUT  !!!!!!!!!!!!!!!!!!!!", flush=True)
                print(f"Tool '{tool_name}' exceeded 1200 seconds and will be terminated.", flush=True)
                p.terminate()
                p.join()
                outputs.append(
                    ToolMessage(
                        content=f"Error: Tool '{tool_name}' timed out after 1200 seconds and was terminated.",
                        name=tool_name,
                        tool_call_id=tool_call["id"],
                    )
                )
            elif "error" in return_dict:
                print(f"!!!!!!!!!!!!!!!!!!!!  ERROR: TOOL FAILED  !!!!!!!!!!!!!!!!!!!!", flush=True)
                print(f"Tool '{tool_name}' failed with error:\n{return_dict['error']}", flush=True)
                outputs.append(
                    ToolMessage(
                        content=(
                            f"Error: Tool '{tool_name}' failed. Exception Traceback:\n{return_dict['error']}"
                        ),
                        name=tool_name,
                        tool_call_id=tool_call["id"],
                    )
                )
            else:
                print(f"--- Tool '{tool_name}' finished successfully. ---", flush=True)
                tool_result = return_dict.get("result")

                if tool_name == "vision_query_with_pts":
                    # vision_query_with_pts returns a list of OpenAI-style content
                    # parts: {"type": "text", ...} for the layout report and
                    # {"type": "image_url", "image_url": {"url": "data:image/jpeg;base64,..."}}
                    # for each level_*.png. Tool messages can't carry image_url
                    # parts directly through the OpenAI API, so split them: text
                    # goes into the ToolMessage (paired with tool_call_id), images
                    # ride along in a follow-up HumanMessage. This matches the
                    # vLLM Gemma image format we verified end-to-end.
                    text_content = ""
                    image_parts = [{
                        "type": "text",
                        "text": "Here are the visual context images from the vision_query_with_pts tool:",
                    }]
                    image_count = 0
                    if isinstance(tool_result, list):
                        for part in tool_result:
                            if not isinstance(part, dict):
                                continue
                            if part.get("type") == "text":
                                text_content += part.get("text", "") + "\n"
                            elif part.get("type") == "image_url":
                                image_parts.append(part)
                                image_count += 1
                    print(f"[VISION] Collected {image_count} image(s) from tool result", flush=True)

                    final_text = text_content.strip() or "Tool vision_query_with_pts executed successfully."
                    outputs.append(
                        ToolMessage(
                            content=final_text,
                            name=tool_name,
                            tool_call_id=tool_call["id"],
                        )
                    )
                    if len(image_parts) > 1:
                        outputs.append(HumanMessage(content=image_parts))
                else:
                    outputs.append(
                        ToolMessage(
                            content=json.dumps(tool_result),
                            name=tool_name,
                            tool_call_id=tool_call["id"],
                        )
                    )

            # Keep original query_change_args check logic
            if tool_name == "change_size":
                query_change_args = inputs.get("query_change_args", {})
                for key, value in query_change_args.items():
                    if value != tool_args.get(key):
                        return {
                            "messages": ToolMessage(
                                content=(
                                    "The change you want to make is not aligned with the last query. "
                                    "Please make sure the changed entity is the one that was queried in the last step."
                                ),
                                name="error",
                            )
                        }
            elif tool_name == "vision_query_with_pts":
                query_change_args = tool_args

        # Build return agent_state
        agent_state["messages"] = outputs
        if query_change_args:
            agent_state["query_change_args"] = query_change_args

        current_count = inputs.get("tool_call_count", 0)

        # Add the number of tools called in this step
        num_called_this_step = len(message.tool_calls)

        # Update the count in the state to be returned
        agent_state["tool_call_count"] = current_count + num_called_this_step

        # Also update the global counter (persists even when exceptions occur)
        tool_call_counter["count"] = current_count + num_called_this_step

        return agent_state


def route_after_tools(state: AgentState):
    print("\n--- ROUTER: route_after_tool ---")

    # Find the latest tool call request (stored in call_agent's AIMessage)
    tool_requests = next(
        (m.tool_calls for m in reversed(state["messages"]) if isinstance(m, AIMessage) and m.tool_calls),
        []
    )
    for tool_call in tool_requests:
        if tool_call["name"] == "change_path_width":
            print("--- ROUTING: Found change_path_width, flow END ---")
            return "end_flow"
    print("--- ROUTING: Found find_target_shape or other tool, returning to call_agent ---")
    return "continue"


def should_continue(state: AgentState) -> str:
    """
    Router function: Check if the latest message (usually AIMessage) in AgentState contains tool calls.
    """
    last_message = state["messages"][-1]

    # Check if LLM output contains tool calls
    if last_message.tool_calls:
        # If there are tool calls, return "continue" to go to call_tools
        return "continue"
    else:
        # If no tool calls, return "end_flow" to end the process
        return "end_flow"


def run_agent(prompt: str):
    initial_state: AgentState = {
        "messages": [
            system_message,
            HumanMessage(content=prompt)
        ],
        "drc_errors": [prompt],
        "tool_call_count": 0
    }
    # One iteration = call_agent -> call_tools = 2 node transitions
    # So recursion_limit needs to be iterations * 2
    result = graph.invoke(initial_state, {"recursion_limit": args.iterations * 2 + 1})
    return result


if __name__ == "__main__":
    separator = "=" * 80
    print(f"\n\n\n{separator}")
    print("LLM Agent Run - New Conversation Initialized")
    print(f"Timestamp: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{separator}\n")

    parser = argparse.ArgumentParser(description="run the DRC fixing agent")
    parser.add_argument("--drc_rpt_path", type=str, help="Initial DRC error report path", required=True)
    parser.add_argument("--iterations", type=int, default=8, help="Maximum number of iterations for the agent")
    parser.add_argument("--temperature", type=float, default=0.7, help="LLM temperature setting")
    args = parser.parse_args()

    with open(args.drc_rpt_path, "r") as f:
        drc_error = f.read()

    # ============================================================================
    # LLM: a vision-capable model served by an OpenAI-compatible server, e.g. a
    # local vLLM instance started with --enable-auto-tool-choice
    # --tool-call-parser <parser>. The endpoint comes from VLLM_BASE_URL; the
    # model name is set below and must match the served model name.
    # ============================================================================
    llm = ChatOpenAI(
        # model="Qwen/Qwen3.5-122B-A10B",
        # model="google/gemma-4-31B-it",
        model="qwen3.5-122b",
        openai_api_base=os.environ.get("VLLM_BASE_URL", "http://localhost:9888/v1"),
        openai_api_key="vllm_fake_key",
        temperature=args.temperature,
        timeout=600.0,
        max_retries=0,
        extra_body={"chat_template_kwargs": {"enable_thinking": True}},
        model_kwargs={"tool_choice": "auto"},
    )

    tools = [vision_query_with_pts, change_shape, add_shape, move_cell, query_drc_report]
    llm_with_tools = llm.bind_tools(tools)

    system_prompt_content = """
You are an expert AI assistant specializing in fixing Design Rule Checking (DRC) errors in GDS layout files. You have **vision capabilities** that allow you to analyze layout images in addition to text descriptions. Your goal is to function as an autonomous agent that iteratively analyzes DRC reports, understands the geometric context of the layout through both text AND visual inspection, applies targeted fixes, and **verifies the outcome** until the error is resolved.

**Your Core Workflow (The Fix-and-Verify Loop):**

Your entire process should follow this mandatory iterative loop:

1.  **Analyze the Goal:** The user will provide you with an initial DRC error report. Carefully read the error type, the message, the layers involved, and the exact coordinates. This is your starting problem.

2.  **Observe the Environment (Multi-Modal):**
    * Your first action in each loop must be to use the `vision_query_with_pts` tool to understand the layout around the current error.
    * **IMPORTANT:** This tool returns BOTH text descriptions AND layout images (level_0.png, level_1.png, level_2.png, level_3.png). You MUST analyze both the text AND the images to fully understand the spatial layout.
    * The images show the actual geometric layout with colors representing different layers. Use them to understand:
        - Spatial relationships between shapes (above, below, left, right, overlapping)
        - The exact location and size of the DRC error region (highlighted)
        - Neighboring structures that might be affected by changes
    * **Choose the observation levels (`"first"`, `"second"`, `"third"`) based on the error's complexity.** For simple errors, `level=["first"]` might be sufficient. A good general starting point is `level=["first", "second"]`. If the surrounding area is dense or the fix might have wide-ranging effects, add `"third"` to get the full picture.

3.  **Reason and Plan (Using Visual Evidence):**
    * Based on BOTH the text output AND the images from `vision_query_with_pts`, analyze the spatial relationships and formulate a precise hypothesis for a fix.
    * Reference what you see in the images when explaining your reasoning.
    * Some fixes might require a single action, while others may need a sequence of modifications. Plan all the necessary steps. For example: "To fix this, I first need to move cell instance X, and then reshape a polygon in cell instance Y."

4.  **Act (Execute the Fix):**
    * Call the chosen modification tool(s) (`move_cell`, `change_shape`, `add_shape`) with the correct parameters to execute your plan.
    * **CRITICAL RULE:** When using `move_cell` or `change_shape`, you **MUST** use the exact same `cell_name`, `type`, `direct_layers`, `context_layers`, and `query_pts` from the `vision_query_with_pts` call you are basing your action on. This is non-negotiable and ensures you modify the correct object in the correct context. So this means whenever you call `move_cell` or `change_shape`, you must guarantee that the gds file has not changed since the last `vision_query_with_pts` call. Or else you must re-query with `vision_query_with_pts` to get the latest context before making a change.

5.  **Verify the Result:**
    * **Once you have completed a single action or a sequence of actions that you believe constitutes a complete fix,** call the `query_drc_report` tool.
    * You must decide the appropriate moment for verification. There is no need to run it after every single modification if a fix requires multiple steps.
    * Pass the path of the newly modified GDS file to this tool to check if your fix worked and if you introduced any new errors.

6.  **Re-evaluate and Repeat:**
    * Analyze the new DRC report from the previous step.
    * **If the original error is gone and no new critical errors have appeared,** your job is done. Announce the successful fix.
    * **If the error persists or a new error has been introduced,** you must restart the loop from **Step 2: Observe the Environment**, using the information from the new DRC report to inform your next attempt.

**Tool Usage Guidelines:**

* **`vision_query_with_pts`**: Your "eyes". Use it at the beginning of every iteration to gather fresh information. Be strategic about which levels you query. **Always analyze both the text output and the accompanying images.**
* **`move_cell` / `change_shape` / `add_shape`**: Your "hands". Use these to execute a single, precise change or a sequence of changes.
* **`query_drc_report`**: Your "verifier". Use this tool after you have applied a complete set of changes to validate the result and guide your next loop.

**Handling Simple/Isolated Cases:**
- If Level 2 or Level 3 return "No shapes found" or "No context shapes", this means the error shape is **isolated** with no nearby neighbors.
- For isolated shapes, you have ALL the information you need from Level 1 alone. This is actually a simpler case to fix!
- Proceed confidently with your fix based on the Level 1 shape properties (dimensions, coordinates, layer).
- Simple width/spacing violations on isolated shapes are often the most straightforward to fix - just adjust the shape dimensions to meet the DRC rule requirement.

**CRITICAL:** You must ALWAYS provide a response after analyzing the query results and images. Even if the layout appears simple or the shape is isolated, you should:
1. Describe what you observe in the images (shape, layer, dimensions)
2. Identify why it violates the DRC rule
3. Propose and execute your fix

Think step-by-step and be methodical. Your objective is to resolve the DRC error by intelligently iterating through the **Observe -> Act -> Verify** cycle. Leverage your vision capabilities to understand the layout better than text alone would allow.
"""
    system_message = SystemMessage(content=system_prompt_content)

    tool_node = BasicToolNode(tools)
    workflow = StateGraph(AgentState)
    workflow.add_node("call_agent", call_llm)
    workflow.add_node("call_tools", tool_node)
    workflow.add_edge("call_tools", "call_agent")
    workflow.add_conditional_edges(
        "call_agent",
        should_continue,
        {
            "continue": "call_tools",
            "end_flow": END
        }
    )
    workflow.set_entry_point("call_agent")
    workflow.set_finish_point("call_agent")
    graph = workflow.compile()

    # Reset the global tool call counter before each run
    tool_call_counter["count"] = 0
    cost_tracker.reset()
    recursion_limit_reached = False

    try:
        final_state = run_agent(drc_error)
        # On success, get count from state (should match global counter)
        final_tool_count = final_state.get("tool_call_count", tool_call_counter["count"])
    except GraphRecursionError as e:
        recursion_limit_reached = True
        print(f"\n{separator}")
        print("AGENT RUN HIT RECURSION LIMIT:")
        print(str(e))
        print(f"{separator}\n", flush=True)
        # Use the global counter which persists even when exception occurs
        final_tool_count = tool_call_counter["count"]
    except Exception as e:
        print(f"\n{separator}")
        print("AGENT RUN FAILED DUE TO ERROR:")
        print(str(e))
        print(f"{separator}\n", flush=True)
        # Use the global counter for any other exception as well
        final_tool_count = tool_call_counter["count"]

    finally:
        model_name = getattr(llm, "model_name", None) or getattr(llm, "model", "unknown")
        cost_data = cost_tracker.save_cost_json(model_name)
        print(f"\n{separator}")
        status = "RECURSION LIMIT REACHED" if recursion_limit_reached else "COMPLETE"
        print(f"AGENT RUN {status}. TOTAL TOOL CALLS: {final_tool_count}")
        print(
            f"TOKEN USAGE: input={cost_data['input_tokens']}, "
            f"output={cost_data['output_tokens']}, total={cost_data['total_tokens']}"
        )
        print(
            f"ESTIMATED COST: ${cost_data['total_cost_usd']:.6f} "
            f"(input=${cost_data['input_cost_usd']:.6f}, output=${cost_data['output_cost_usd']:.6f})"
        )
        print(f"{separator}\n", flush=True)
